import React, { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import type { Variants } from "framer-motion";

// --- Types ------------------------------------------------------------------
type PushFn = (path: string) => void;

// --- Helpers ---------------------------------------------------------------
function normalizePath(path: string) {
  return path && path.startsWith("/") ? path : "/" + (path || "");
}

// Shared background used across screens
const bgStyle: React.CSSProperties = {
  background:
    "linear-gradient(135deg, #0d1b2a 0%, #1e1a46 50%, #2d1f5c 75%, #3a2a70 100%)",
};

// Simple local validator (fallback)
function localHeuristicValid(text: string) {
  const t = (text || "").trim();
  if (t.length < 10) return false;
  const hasSep = /,|\sin\s|\sof\s|\sat\s|\sduring\s/i.test(t);
  return hasSep;
}

// Simulated AI validator (fallback if server/key not available)
function simulatedAIValidate(text: string) {
  const t = (text || "").trim();
  if (t.length < 10) {
    return { valid: false, reason: "Tiny but mighty… but too tiny. Add more detail (≥ 10 chars)." };
  }
  const lower = t.toLowerCase();
  const hasPreposition = /(,|\s(in|at|on|during|around|before|after)\s)/i.test(t);
  const roleWords = [
    "king","queen","leader","president","chief","senator","representative","mayor","general",
    "commander","captain","minister","governor","judge","member","emperor","consul","dictator",
    "chancellor","prime minister","chair","speaker","treasurer","adviser","advisor"
  ];
  const hasRoleWord = roleWords.some((w) => lower.includes(w));
  const articleRolePattern = /^(a|an|the)\s+\w+/i.test(t);
  const maybeRole = hasRoleWord || articleRolePattern;
  const settingPattern = /(,\s*.+|\s(in|at|on|during|around|before|after)\s+[^,]+)$/i;
  const maybeSetting = settingPattern.test(t) || hasPreposition;
  if (!maybeRole && !maybeSetting) {
    return { valid: false, reason: "I see words, but not a role *and* a setting. Try ‘a captain in the Age of Exploration’." };
  }
  if (!maybeRole) {
    return { valid: false, reason: "I’m missing the **role**. Who are you? e.g., ‘a senator in ancient Rome’." };
  }
  if (!maybeSetting) {
    return { valid: false, reason: "I’m missing the **setting** (time/place)—add ‘in medieval England’ or ‘on Mars, 2199’." };
  }
  const sepMatch = t.match(/(?:,|\s(?:in|at|on|during|around|before|after)\s)(.+)$/i);
  if (sepMatch && sepMatch[1].trim().length < 3) {
    return { valid: false, reason: "The setting looks a bit shy—make it clearer." };
  }
  return { valid: true, reason: "Looks like a role and a setting to me." };
}

// Call our secure server; fall back to simulated AI on any failure
async function validateRoleWithServerOrSim(inputText: string) {
  try {
    const res = await fetch("/api/validate-role", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: inputText }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = (await res.json()) as { valid?: boolean; reason?: string };
    if (typeof data?.valid === "boolean") {
      return { source: "server-ai", valid: data.valid, reason: data.reason || "" };
    }
    throw new Error("Bad server response");
  } catch {
    const r = simulatedAIValidate(inputText);
    return { source: "simulated-ai", ...r };
  }
}

// --- Minimal hash router ---------------------------------------------------
function useHashRoute() {
  const [route, setRoute] = useState<string>(
    () => window.location.hash.replace("#", "") || "/"
  );
  useEffect(() => {
    const onHashChange = () =>
      setRoute(window.location.hash.replace("#", "") || "/");
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);
  const push: PushFn = (path) => {
    window.location.hash = normalizePath(path);
  };
  return { route, push };
}

// --- Screens ---------------------------------------------------------------
function SplashScreen({ onStart }: { onStart: () => void }) {
  const [showButton, setShowButton] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setShowButton(true), 1000);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="min-h-[100dvh] flex items-center justify-center px-5" style={bgStyle}>
      <div className="w-full max-w-md text-center select-none space-y-5">
        <motion.h1
          initial={{ opacity: 0, y: 20, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 18 }}
          className="text-4xl sm:text-5xl font-extrabold leading-tight tracking-tight bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-500 bg-clip-text text-transparent drop-shadow-[0_2px_10px_rgba(0,0,0,0.55)]"
        >
          aMAZE'n Politics
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.35 }}
          className="text-base sm:text-lg bg-gradient-to-r from-indigo-200 via-violet-200 to-amber-200 bg-clip-text text-transparent"
        >
          Discover yourself — and your best!
        </motion.p>

        <div className="mt-8 flex justify-center min-h-[52px]">
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: showButton ? 1 : 0 }}
            transition={{ type: "spring", stiffness: 250, damping: 22 }}
            style={{ visibility: showButton ? "visible" : "hidden" }}
            onClick={onStart}
            className="w-[14rem] rounded-2xl px-4 py-3 text-base font-semibold bg-gradient-to-r from-amber-300 to-amber-500 text-[#0b1335] shadow-lg active:scale-[0.98] focus:outline-none focus:ring-2 focus:ring-amber-300/60"
          >
            Start!
          </motion.button>
        </div>
      </div>
    </div>
  );
}

function IntroScreen({ push }: { push: PushFn }) {
  const paragraphs = [
    "Ready to be aMAZEd?",
    "Life is a branching journey where every choice can lead to a different outcome.",
    "In aMaze’n Politics you travel a constantly shifting maze, where private choices intersect with public life.",
    "Know yourself—and become your best!",
    "Ready to pick your path?",
  ];

  const [visibleCount, setVisibleCount] = useState(0);

  useEffect(() => {
    if (visibleCount < paragraphs.length) {
      const t = setTimeout(() => setVisibleCount((c) => c + 1), 1500);
      return () => clearTimeout(t);
    }
  }, [visibleCount, paragraphs.length]);

  const allShown = visibleCount >= paragraphs.length;

  return (
    <div className="min-h-[100dvh] flex items-center justify-center px-5" style={bgStyle}>
      <div className="w-full max-w-md text-center space-y-5">
        {paragraphs.map((text, i) => (
          <motion.p
            key={i}
            initial={{ opacity: 0 }}
            animate={{ opacity: i < visibleCount ? 1 : 0 }}
            transition={{ duration: 0.8 }}
            className={
              i === 0
                ? "text-2xl sm:text-3xl font-extrabold bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-500 bg-clip-text text-transparent"
                : i === paragraphs.length - 1
                ? "text-lg sm:text-xl bg-gradient-to-r from-indigo-200 via-violet-200 to-amber-200 bg-clip-text text-transparent"
                : "text-lg sm:text-xl text-white/90"
            }
          >
            {text}
          </motion.p>
        ))}

        <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center min-h-[104px]">
          {allShown && (
            <>
              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
                onClick={() => push("/role")}
                className="w-[14rem] rounded-2xl px-5 py-3 font-semibold text-lg bg-gradient-to-r from-indigo-400 to-purple-500 text-white shadow-lg hover:scale-[1.02] active:scale-[0.98] mx-auto sm:mx-0"
              >
                Free Play
              </motion.button>
              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.1, duration: 0.5 }}
                onClick={() => push("/campaign")}
                className="w-[14rem] rounded-2xl px-5 py-3 font-semibold text-lg bg-gradient-to-r from-amber-400 to-yellow-500 text-[#0b1335] shadow-lg hover:scale-[1.02] active:scale-[0.98] mx-auto sm:mx-0"
              >
                Campaign Mode
              </motion.button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function RoleSelectionScreen({ push }: { push: PushFn }) {
  const roles = [
    { icon: "🇺🇸", label: "President of the USA" },
    { icon: "🏛️", label: "Member of the People’s Assembly in Classical Athens" },
    { icon: "🪐", label: "Leader of a Martian Colony" },
    { icon: "🪶", label: "A Native American chief as the settlers arrive" },
    { icon: "❓", label: "Suggest your own" },
  ];

  const [showModal, setShowModal] = useState(false);
  const [input, setInput] = useState("");
  const [aiMsg, setAiMsg] = useState("");
  const [checking, setChecking] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const openSuggest = () => {
    setInput("");
    setAiMsg("");
    setChecking(false);
    setShowModal(true);
    setTimeout(() => inputRef.current?.focus(), 50);
  };
  const closeSuggest = () => {
    setShowModal(false);
    setAiMsg("");
  };

  const amusingFallbacks = [
    "That sounds like a vibe, not a role *with* a setting. Try something like ‘navigator in a Bronze Age fleet’.",
    "Close! Give me a role **and** a setting. E.g., ‘city treasurer in Renaissance Florence’.",
    "Mystery unlocked… almost. Add a where/when: ‘cybernetics minister on Luna, 2199’.",
  ];

  async function handleConfirm() {
    if (checking) return;
    setChecking(true);
    setAiMsg("");
    const { valid, reason } = await validateRoleWithServerOrSim(input);
    if (!valid) {
      const witty =
        reason && reason.length > 0 ? reason : amusingFallbacks[Math.floor(Math.random() * amusingFallbacks.length)];
      setAiMsg(witty);
      setChecking(false);
      setInput("");
      setTimeout(() => inputRef.current?.focus(), 50);
      return;
    }
    setAiMsg("Nice! That's a clear role and setting.");
    setChecking(false);
    // TODO: define the next route once you decide the flow
    // push("/intro");
    closeSuggest();
  }

  const container: Variants = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.08, delayChildren: 0.2 } },
  };
  const itemVariants: Variants = {
    hidden: { opacity: 0, y: 8, scale: 0.98 },
    show: { opacity: 1, y: 0, scale: 1, transition: { type: "spring", stiffness: 260, damping: 22 } },
  };
  

  return (
    <div className="min-h-[100dvh] flex items-center justify-center px-5" style={bgStyle}>
      <div className="w-full max-w-md text-center select-none">
        <h2 className="text-3xl font-extrabold bgts-gradient-to-r from-amber-200 via-yellow-300 to-amber-500 bg-clip-text text-transparent">
          Choose Your Role
        </h2>
        <motion.ul variants={container} initial="hidden" animate="show" className="mt-6 space-y-4">
          {roles.map((r, idx) => (
            <motion.li key={idx} variants={itemVariants}>
              <button
                onClick={() => (r.icon === "❓" ? openSuggest() : push("/intro"))}
                className="w-full px-5 py-4 rounded-full bg-white/5 text-white/90 border border-white/10 hover:bg-white/10 hover:border-white/20 transition transform active:scale-[0.98] flex items-center gap-3 text-left shadow-[inset_0_0_0_1px_rgba(255,255,255,0.04)]"
              >
                <span className="text-xl leading-none">{r.icon}</span>
                <span className="flex-1 text-base">{r.label}</span>
              </button>
            </motion.li>
          ))}
        </motion.ul>

        {/* Suggest-your-own Modal */}
        <AnimatePresence>
          {showModal && (
            <motion.div
              className="fixed inset-0 z-50 grid place-items-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <div className="absolute inset-0 bg-black/60" onClick={closeSuggest} />
              <motion.div
                role="dialog"
                aria-modal="true"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ type: "spring", stiffness: 300, damping: 24 }}
                className="relative w-[92%] max-w-md rounded-2xl p-5 bg-neutral-900/90 backdrop-blur border border-white/10 shadow-xl text-left"
              >
                <button
                  aria-label="Close"
                  onClick={closeSuggest}
                  className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 grid place-items-center text-white"
                >
                  ×
                </button>
                <h3 className="text-xl font-semibold bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-500 bg-clip-text text-transparent">
                  Suggest your own role
                </h3>
                <p className="mt-2 text-white/80 text-sm">
                  Write a <span className="font-semibold">role</span> and a <span className="font-semibold">setting</span>.
                  For example: <em>“a king in medieval England”</em> or <em>“a partisan leader in World War 2.”</em>
                </p>
                <div className="mt-4">
                  <input
                    ref={inputRef}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Type a role and a setting (a king in medieval England, a partisan leader in World War 2, etc.)"
                    className="w-full px-4 py-3 rounded-xl bg-white/95 text-[#0b1335] placeholder:text-[#0b1335]/60 focus:outline-none focus:ring-2 focus:ring-amber-300/60"
                  />
                </div>

                {aiMsg && (
                  <motion.div
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-3 text-amber-200/95 text-sm"
                  >
                    {aiMsg}
                  </motion.div>
                )}

                <div className="mt-5 flex gap-3 justify-end">
                  <button
                    onClick={closeSuggest}
                    className="rounded-xl px-4 py-2 text-sm bg-white/10 text-white hover:bg-white/15"
                  >
                    Close
                  </button>
                  <button
                    disabled={input.trim().length < 10 || checking}
                    onClick={handleConfirm}
                    className={`rounded-xl px-4 py-2 text-sm font-semibold shadow ${
                      input.trim().length < 10 || checking
                        ? "bg-amber-300/40 text-[#0b1335]/60 cursor-not-allowed"
                        : "bg-gradient-to-r from-amber-300 to-amber-500 text-[#0b1335]"
                    }`}
                  >
                    {checking ? "Checking…" : "Confirm"}
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function CampaignScreen() {
  return (
    <div className="min-h-[100dvh] flex items-center justify-center px-5" style={bgStyle}>
      <div className="w-full max-w-sm text-center select-none">
        <h2 className="text-3xl font-extrabold bg-gradient-to-r from-indigo-200 via-violet-200 to-amber-200 bg-clip-text text-transparent">
          Campaign mode
        </h2>
        <p className="mt-2 text-white/85">(Coming soon)</p>
      </div>
    </div>
  );
}

// --- App Router ------------------------------------------------------------
export default function App() {
  const { route, push } = useHashRoute();

  if (route === "/intro") {
    return <IntroScreen push={push} />;
  }
  if (route === "/role") {
    return <RoleSelectionScreen push={push} />;
  }
  if (route === "/campaign") {
    return <CampaignScreen />;
  }
  return <SplashScreen onStart={() => push("/intro")} />;
}

// --- Dev sanity checks (non-breaking) -------------------------------------
if (typeof window !== "undefined") {
  try {
    console.assert(normalizePath("intro") === "/intro", "normalizePath should prefix slash");
    console.assert(normalizePath("/intro") === "/intro", "normalizePath should keep leading slash");
    const INTRO_LINES = [
      "Ready to be aMAZEd?",
      "Life is a branching journey where every choice can lead to a different outcome.",
      "In aMaze’n Politics you travel a constantly shifting maze, where private choices intersect with public life.",
      "Know yourself—and become your best!",
      "Ready to pick your path?",
    ];
    console.assert(INTRO_LINES.length === 5, "Intro should have 5 lines");
    console.assert(INTRO_LINES[0].startsWith("Ready to be aMAZE"), "Intro first line text check");
    console.assert(INTRO_LINES[4].includes("pick your path"), "Intro last line text check");

    console.assert(localHeuristicValid("a king in medieval England") === true, "Heuristic should pass clear role+setting");
    console.assert(localHeuristicValid("wizard") === false, "Heuristic should fail short/unclear");

    console.assert(simulatedAIValidate("a partisan leader in World War 2").valid === true, "Sim AI: should pass role+setting");
    console.assert(simulatedAIValidate("in space").valid === false, "Sim AI: missing role");
  } catch (e) {
    console.warn("Dev checks failed:", e);
  }
}
