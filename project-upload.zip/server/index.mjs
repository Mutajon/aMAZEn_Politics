// server/index.mjs  (Node 18+)
import 'dotenv/config';
import express from 'express';
import cors from 'cors';

const app = express();
const PORT = 8787;

app.use(cors({ origin: 'http://localhost:5173' }));
app.use(express.json());

// Simple health check
app.get('/api/health', (_req, res) => res.json({ ok: true }));

// Secure validator endpoint
app.post('/api/validate-role', async (req, res) => {
  try {
    const { text } = req.body || {};
    if (typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({ valid: false, reason: 'No text provided.' });
    }

    const key = process.env.OPENAI_API_KEY;
    if (!key) {
      return res.status(500).json({ valid: false, reason: 'Server missing OPENAI_API_KEY.' });
    }

    const payload = {
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content:
            'You are a strict validator. Determine if the user\'s text clearly contains BOTH a role AND a setting (time/place/context). Respond ONLY with JSON: {"valid": boolean, "reason": string}. Be concise, witty if invalid.',
        },
        { role: 'user', content: text },
      ],
      response_format: { type: 'json_object' },
      temperature: 0.2,
    };

    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify(payload),
    });

    const data = await r.json();
    const content = data?.choices?.[0]?.message?.content ?? '{}';

    let parsed = null;
    try { parsed = JSON.parse(content); } catch { /* ignore */ }

    if (!parsed || typeof parsed.valid !== 'boolean') {
      return res.json({ valid: false, reason: 'AI response not JSON.' });
    }

    return res.json({ valid: !!parsed.valid, reason: parsed.reason || '' });
  } catch (e) {
    console.error('validate-role error:', e);
    return res.status(500).json({ valid: false, reason: 'Server error.' });
  }
});

app.listen(PORT, () => {
  console.log(`API ready on http://localhost:${PORT}`);
});
